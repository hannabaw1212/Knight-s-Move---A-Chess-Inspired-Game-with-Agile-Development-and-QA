package model;

public class IsForgetSquare extends Square{

	public IsForgetSquare(int[] corr, boolean isVisited, String color) {
		super(corr, isVisited, color);
	}

}
