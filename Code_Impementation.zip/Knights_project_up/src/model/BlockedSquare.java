package model;

public class BlockedSquare  extends Square{

	public BlockedSquare(int[] corr, boolean isVisited, String color) {
		super(corr, isVisited, color);
		// TODO Auto-generated constructor stub
	}	
	



}
