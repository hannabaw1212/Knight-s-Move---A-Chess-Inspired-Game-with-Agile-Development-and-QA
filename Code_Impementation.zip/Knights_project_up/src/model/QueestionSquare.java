package model;

public class QueestionSquare extends Square{

	public QueestionSquare(int[] corr, boolean isVisited, String color) {
		super(corr, isVisited, color);
		// TODO Auto-generated constructor stub
	}

}
