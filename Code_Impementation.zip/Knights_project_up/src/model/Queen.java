package model;

import java.util.ArrayList;

// queen class
public class Queen extends GameObject{
	private static int idCounter = 1;

	public Queen() {
		super();
	}
	
	
	public ArrayList<Point>getQueenPossibleMoves(int colQ, int rowQ) {
		ArrayList<Point>p = new ArrayList<>();
		// here in the 2 for loops we get the all possible moves of the queen
		for(int relevRow = 0; relevRow < 8; relevRow++) {

			for(int releveColumn = 0 ; releveColumn < 8; releveColumn++) {
				if (relevRow == rowQ || colQ == releveColumn || 
						Math.abs(relevRow - rowQ) == Math.abs(releveColumn - colQ)) {
					p.add(new Point(relevRow, releveColumn));
				}
			}
		}
		return p;
	}
	
	@Override
	public void MoveBias() {
		
	}
}	

